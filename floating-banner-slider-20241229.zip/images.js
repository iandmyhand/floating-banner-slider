callback([
  {
    imageUrl: "images/dorina-perry-yQAuEZ6q2yo-unsplash.jpg",
    link: "https://unsplash.com/photos/yQAuEZ6q2yo",
  },
  {
    imageUrl: "images/jonatan-pie-Lyxlh8vuRmY-unsplash.jpg",
    link: "https://unsplash.com/photos/Lyxlh8vuRmY",
  },
  {
    imageUrl: "images/marie-kristin-krause-h_JyDNeuxPc-unsplash.jpg",
    link: "https://unsplash.com/photos/h_JyDNeuxPc",
  },
  {
    imageUrl: "images/pascal-debrunner-nbJyIC2tTZQ-unsplash.jpg",
    link: "https://unsplash.com/photos/nbJyIC2tTZQ",
  },
  {
    imageUrl: "images/samsung-memory-QpLJ8Kw5S0Q-unsplash.jpg",
    link: "https://unsplash.com/photos/QpLJ8Kw5S0Q",
  },
]);
